const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const fs = require("fs");
const input = require("input");
const http = require("http");
const https = require("https");

const { performance } = require('perf_hooks');
const puppeteer = require('puppeteer');
// قائمة التوكنات المراقبة
const trackedTokens = {};

// بدء مراقبة توكن جديد
async function startTrackingToken(token) {
  if (trackedTokens[token]) return;
  const url = `https://gmgn.ai/sol/token/${token}`;
  const startTime = new Date();
  let firstPrice = null;
  let lastPrice = null;
  let maxIncrease = 0;
  let reached50 = false;
  let stopped = false;

  // إطلاق متصفح Puppeteer لكل توكن مع إعدادات محاكاة متصفح حقيقي (وضع headless)
  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-blink-features=AutomationControlled'] });
  const page = await browser.newPage();
  // تعيين user-agent حقيقي
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
  // إزالة متغيرات تدل على الأتمتة
  await page.evaluateOnNewDocument(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });
  await page.goto(url, { waitUntil: 'networkidle2', timeout: 360000 });

  // جلب أول سعر
  async function getPrice() {
    try {
      // جرب أولاً السلكتور .price
      await page.waitForSelector('.price', { timeout: 7000 });
      const priceText = await page.$eval('.price', el => el.textContent);
      const price = parseFloat(priceText.replace(/[^\d.]/g, ''));
      if (!isNaN(price)) {
        console.log(`[${token}] تم جلب السعر من .price:`, price);
        return price;
      }
    } catch (e) {
      console.log(`[${token}] لم يتم العثور على .price أو حدث خطأ:`, e.message);
    }
    // إذا لم يوجد .price جرب استخراج السعر من كل الصفحة
    try {
      const bodyText = await page.evaluate(() => document.body.innerText);
      // ابحث عن أول رقم دولار في الصفحة
      const match = bodyText.match(/\$([0-9]+\.[0-9]+)/);
      if (match && match[1]) {
        const price = parseFloat(match[1]);
        if (!isNaN(price)) {
          console.log(`[${token}] تم جلب السعر عبر regex:`, price);
          return price;
        }
      }
      // اطبع جزء من الصفحة للمساعدة في التصحيح
      console.log(`[${token}] لم يتم العثور على السعر، جزء من الصفحة:\n`, bodyText.slice(0, 500));
    } catch (e) {
      console.log(`[${token}] خطأ أثناء قراءة نص الصفحة:`, e.message);
    }
    return null;
  }

  // كرر محاولة جلب السعر الأول حتى تحصل على قيمة صحيحة
  while (firstPrice === null) {
    firstPrice = await getPrice();
    if (firstPrice === null) {
      await new Promise(r => setTimeout(r, 2000)); // انتظر ثانيتين وأعد المحاولة
    }
  }
  lastPrice = firstPrice;
  trackedTokens[token] = {
    token,
    startTime,
    firstPrice, // سيبقى ثابتًا
    lastPrice,
    maxIncrease,
    reached50,
    stopped,
    browser,
    page
  };

  // تحديث السعر كل 10 ثوانٍ
  (async function updateLoop() {
    while (trackedTokens[token] && !trackedTokens[token].stopped) {
      const price = await getPrice();
      // تحقق من أن التوكن ما زال موجودًا ولم يُحذف أثناء الانتظار
      if (!trackedTokens[token]) break;
      if (price) {
        // تحديث lastPrice فقط إذا كان السعر الجديد أعلى من القيمة الحالية
        if (price > trackedTokens[token].lastPrice) {
          trackedTokens[token].lastPrice = price;
        }
        // لا تغير firstPrice بعد تعيينه أول مرة
        const increase = ((price - trackedTokens[token].firstPrice) / trackedTokens[token].firstPrice) * 100;
        if (increase > trackedTokens[token].maxIncrease) trackedTokens[token].maxIncrease = increase;
        // إذا لم يصل بعد إلى 50% وحققها الآن، ثبّت reached50 على true
        if (!trackedTokens[token].reached50 && increase >= 50) {
          trackedTokens[token].reached50 = true;
        }
      }
      await new Promise(r => setTimeout(r, 10000));
    }
    await browser.close();
  })();
}

// حذف التوكن من المراقبة
function stopTrackingToken(token) {
  if (trackedTokens[token]) {
    trackedTokens[token].stopped = true;
    delete trackedTokens[token];
  }
}

// بيانات الدخول تلقائية للسيرفر
const PHONE_NUMBER = "+966XXXXXXXXX";  // ضع رقمك هنا
const PASSWORD = "YOUR_PASSWORD"; // إذا كان لديك كلمة مرور 2FA
const PHONE_CODE = undefined; // يمكن تركه undefined ليتم تجاهله

const apiId = 23299626;
const apiHash = "89de50a19288ec535e8b008ae2ff268d";

console.log("🚀 البوت يعمل الآن 24 ساعة على السيرفر!");

// دالة لتسجيل الدخول والخروج
function logLoginLogout(type) {
  const logFile = 'login_logout_log.txt';
  const now = new Date().toISOString();
  fs.appendFileSync(logFile, `${type},${now}\n`, 'utf8');
}

// تسجيل الدخول
logLoginLogout('login');

// نحاول تحميل الجلسة من ملف
let stringSession = new StringSession("");

if (fs.existsSync("session.txt")) {
  const savedSession = fs.readFileSync("session.txt", "utf8");
  stringSession = new StringSession(savedSession.trim());
}

(async () => {
  console.log("📲 بدء الاتصال بتليجرام...");
  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  // تسجيل الدخول عند الحاجة فقط
  try {
    await client.start({
      phoneNumber: async () => PHONE_NUMBER,
      password: async () => PASSWORD,
      phoneCode: async () => PHONE_CODE,
      onError: (err) => console.log("❌ خطأ:", err),
    });
  } catch (err) {
    if (err.errorMessage === 'AUTH_KEY_DUPLICATED') {
      console.error('❌ AUTH_KEY_DUPLICATED: سيتم حذف الجلسة القديمة وإنشاء جلسة جديدة.');
      fs.unlinkSync('session.txt'); // حذف ملف الجلسة القديمة
      stringSession = new StringSession(""); // إعادة تعيين الجلسة
      await client.start({
        phoneNumber: async () => PHONE_NUMBER,
        password: async () => PASSWORD,
        phoneCode: async () => PHONE_CODE,
        onError: (err) => console.log("❌ خطأ:", err),
      });
    } else {
      throw err; // إعادة رمي الخطأ إذا لم يكن AUTH_KEY_DUPLICATED
    }
  }

  console.log("✅ تم تسجيل الدخول!");
  const sessionString = client.session.save();

  // حفظ الجلسة للاستخدام التالي
  fs.writeFileSync("session.txt", sessionString);
  console.log("💾 تم حفظ الجلسة في session.txt");

  await client.sendMessage("me", { message: "🚀 بوت الإشعارات شغال!" });

  // تحقق من الانضمام للبوتات المطلوبة مرة واحدة فقط في الحياة
  const joinedBotsFile = 'joined_bots.txt';
  if (!fs.existsSync(joinedBotsFile)) {
    try {
      // قائمة البوتات المطلوبة
      const botsToJoin = ['GMGN_sol_bot', 'solBigamout'];
      for (const bot of botsToJoin) {
        // أرسل فقط للبوتات التي تنتهي بـ _bot
        if (bot.endsWith('_bot')) {
          await client.sendMessage(bot, { message: '/start' });
          await sleep(2000);
        } else {
          console.log(`⚠️ تخطي ${bot}: ليس بوت تليجرام.`);
        }
      }
      fs.writeFileSync(joinedBotsFile, 'done');
      console.log('✅ تم الانضمام لكل البوتات المطلوبة لأول مرة.');
    } catch (err) {
      console.error('❌ خطأ أثناء الانضمام للبوتات:', err.message);
    }
  }

  // التتبع والتوجيه
  client.addEventHandler(async (update) => {
    try {
      // تعديل شروط الفلترة لإضافة الفرز الرابع
      if (update.message && typeof update.message.message === "string") {
        const msg = update.message;
        const text = msg.message;

        // فلترة الرسائل التي تحتوي على "counts: 1" أو أكثر و"60 SOL" أو أكثر
        if (/\bcounts:\s*(\d+)\b/i.test(text) && parseInt(text.match(/\bcounts:\s*(\d+)\b/i)[1]) >= 1 &&
            /([6-9]\d|\d{3,})\.\d{2}\s*SOL(\D|$)/.test(text)) {

          // فلترة "5m" بحيث تكون بين 0% و 3000%
          const fiveMinMatch = text.match(/5m\s*\((\d+\.\d+)%\)/);
          if (fiveMinMatch) {
            const fiveMinPercentage = parseFloat(fiveMinMatch[1]);
            if (fiveMinPercentage > 3000) {
              console.log(`⚠️ النسبة 5m (${fiveMinPercentage}%) أكبر من 3000%. تخطي.`);
              return;
            }
          }

          // الفرز الرابع: التحقق من أن عدد الأيام (d) يساوي 0
          const ageMatch = text.match(/age:\s*(\d+)d\s*(\d+)h/);
          if (ageMatch) {
            const days = parseInt(ageMatch[1]);
            if (days !== 0) {
              console.log(`⚠️ عدد الأيام (d) ليس 0. تخطي.`);
              return;
            }
          }

          // فلترة السعر price: $... يجب أن يكون أقل من 0.01
          const priceMatch = text.match(/price:\s*\$?([\deE\.-]+)/i);
          if (priceMatch && priceMatch[1]) {
            let priceValue = parseFloat(priceMatch[1]);
            if (isNaN(priceValue)) {
              // محاولة التحويل من صيغة علمية
              try {
                priceValue = Number(priceMatch[1]);
              } catch {}
            }
            if (!(priceValue < 0.01)) {
              console.log(`⚠️ السعر ${priceValue} أكبر أو يساوي 0.01. تخطي.`);
              return;
            }
          } else {
            // إذا لم يوجد سعر، تخطى
            console.log('⚠️ لم يتم العثور على السعر في الرسالة. تخطي.');
            return;
          }

          const startTime = performance.now();
          // استخراج التوكن بعد ca:
          const caMatch = text.match(/ca:\s*([\w]+)/);
          if (caMatch && caMatch[1]) {
            const token = caMatch[1];
            if (sentTokens.has(token)) {
              console.log(`⚠️ التوكن ${token} تم إرساله مسبقًا. تخطي.`);
              return;
            }
            // طباعة التوكن فقط بدون ca:
            console.log(token);
            // حفظ التوكن في ملف لاستخدامه في بوت sniperoo
            fs.writeFileSync('last_token.txt', token, 'utf8');

            // إرسال أمر الشراء المباشر أولاً بسرعة الضوء

            // إرسال أمر الشراء والتوكن في نفس اللحظة (زمن بلانك)
            const buyMsg = `/buy ${token} ${buyPrice}`;
            client.sendMessage(botUsername, { message: buyMsg });
            client.sendMessage(botUsername, { message: token });
            console.log('✅ تم إرسال أمر الشراء المباشر:', buyMsg);
            console.log('📩 تم إرسال التكوين لمعرفة السعر بعد الشراء.');

            // إضافة التوكن إلى القائمة المرسلة
            sentTokens.add(token);
            fs.appendFileSync(sentTokensFile, `${token}\n`, 'utf8');

            // بدء مراقبة التوكن
            startTrackingToken(token);

            const endTime = performance.now();
            const executionTimeLog = `⏱️ وقت التنفيذ للتوكن ${token}: ${(endTime - startTime).toFixed(2)} مللي ثانية.`;
            console.log(executionTimeLog);
            executionLogsBuffer.push(`${executionTimeLog}\n`);
          }
        }
      }
    } catch (err) {
      console.error("❌ خطأ أثناء التوجيه:", err.message);
    }
  });
})();

const botUsername = 'GMGN_sol_bot';

// دالة التداول التلقائي في بوت GMGN
async function tradeInGMGNBot(client, token) {
  const lastStartFile = 'gmgn_last_start.txt';
  let shouldSendStart = true;
  try {
    // تحقق من آخر إرسال لـ /start
    if (fs.existsSync(lastStartFile)) {
      const lastStartDate = fs.readFileSync(lastStartFile, 'utf8').trim();
      const today = new Date().toISOString().slice(0, 10);
      if (lastStartDate === today) {
        shouldSendStart = false;
      }
    }
    // إرسال /start مرة واحدة فقط يومياً
    if (shouldSendStart) {
      await client.sendMessage(botUsername, { message: '/start' });
      fs.writeFileSync(lastStartFile, new Date().toISOString().slice(0, 10));
      await sleep(2000);
    }
    // إرسال التوكن
    await client.sendMessage(botUsername, { message: token });
    await sleep(3000);

    // استقبال رسائل البوت وطباعة كل رسالة والبحث عن السعر
    let price = null;
    let done = false;
    let lastBotMessage = null;
    const handler = async (update) => {
      // تحقق من أن الرسالة من بوت GMGN بناءً على اسم المستخدم أو peerId
      if (update.message && update.message.peerId && (
            (update.message.peerId.userId && update.message.peerId.userId.toString().includes('GMGN')) ||
            (update.message.peerId.channelId && botUsername.includes('GMGN'))
          )) {
        const text = update.message.message;
        lastBotMessage = text;
        // تحقق أن الرسالة تحتوي على التوكن المطلوب
        if (text.includes(token)) {
          // استخراج السعر من الرسالة
          let priceMatch = text.match(/price:\s*\$?([\d\.]+)/i);
          if (priceMatch && priceMatch[1]) {
            price = parseFloat(priceMatch[1]);
            done = true;
            // طباعة السعر فقط بدون باقي الرسالة وبدون علامة الدولار
            console.log('📩 السعر من GMGN: ' + priceMatch[1]);
            // حساب السعر الجديد بزيادة 1000%
            const newPrice = (price * 10).toFixed(6);
            // إرسال أمر التداول مباشرة
            const orderMsg = `/create limitbuy ${token} 0.5@${newPrice} -exp 86400`;
            await client.sendMessage(botUsername, { message: orderMsg });
            console.log('✅ تم إرسال أمر التداول:', orderMsg);
          } else {
            // إذا لم يوجد سعر، اطبع الرسالة كاملة
            console.log('📩 رسالة من GMGN:\n' + text);
          }
        }
      }
    };
    client.addEventHandler(handler);
    // انتظر حتى يتم استقبال السعر أو انتهاء المهلة
    let tries = 0;
    while (!done && tries < 10) {
      await sleep(1000);
      tries++;
    }
    client.removeEventHandler(handler);
    if (!price) {
      console.log('📩 رد البوت بعد ارسال التوكن:\n' + (lastBotMessage || 'لم يتم استقبال أي رسالة من البوت بعد إرسال التوكن'));
      return;
    }
    // حساب السعر الجديد بزيادة 1000%
    const newPrice = (price * 10).toFixed(6);
    // إرسال أمر التداول
    const orderMsg = `/create limitbuy ${token} 0.5@${newPrice} -exp 86400`;
    await client.sendMessage(botUsername, { message: orderMsg });
    console.log('✅ تم إرسال أمر التداول:', orderMsg);
  } catch (err) {
    console.error('❌ خطأ في التداول مع GMGN:', err.message);
  }
}

// دالة تأخير بسيطة
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

let buyPrice = 0.5; // السعر الافتراضي

const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/delete-all") {
    // مسح محتويات ملف السجلات
    fs.writeFileSync('execution_logs.txt', '', 'utf8');
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`
      <div style='text-align:center;'>
        <div style='font-size:2em;'>🚀 تم مسح جميع السجلات بنجاح!</div>
        <a href="/" style='font-size:1.5em; color:#0078D7;'>العودة إلى الصفحة الرئيسية</a>
      </div>
    `);
    return;
  }

  if (req.method === "POST" && req.url === "/update-price") {
    let body = "";
    req.on("data", chunk => {
      body += chunk.toString();
    });
    req.on("end", () => {
      const params = new URLSearchParams(body);
      const newPrice = parseFloat(params.get("price"));
      if (!isNaN(newPrice) && newPrice > 0) {
        buyPrice = newPrice;
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(`
          <div style='text-align:center;'>
            <div style='font-size:2em;'>✅ تم تحديث السعر بنجاح إلى: ${buyPrice}</div>
            <a href="/" style='font-size:1.5em; color:#0078D7;'>العودة إلى الصفحة الرئيسية</a>
          </div>
        `);
      } else {
        res.writeHead(400, { "Content-Type": "text/html; charset=utf-8" });
        res.end(`
          <div style='text-align:center;'>
            <div style='font-size:2em; color:red;'>❌ السعر المدخل غير صالح!</div>
            <a href="/" style='font-size:1.5em; color:#0078D7;'>العودة إلى الصفحة الرئيسية</a>
          </div>
        `);
      }
    });
    return;
  }

  // ...existing code...
  if (req.method === "GET" && req.url.startsWith("/track_token")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`
      <html lang="ar">
      <head>
        <title>Token Tracker</title>
        <meta http-equiv="refresh" content="10">
        <style>
          body { font-family: Tahoma, Arial, sans-serif; background: #f7f7fa; margin: 0; padding: 0; direction: rtl; }
          h2 { text-align: center; color: #0078D7; margin-top: 30px; letter-spacing: 1px; }
          .tokens-container { max-width: 700px; margin: 30px auto; }
          .token-block {
            background: #fff;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 8px #0001;
            padding: 18px 22px 12px 22px;
            margin-bottom: 18px;
            border-radius: 10px;
            transition: box-shadow 0.2s;
            position: relative;
          }
          .token-block:hover { box-shadow: 0 4px 16px #0002; }
          .token-label { color: #333; font-weight: bold; display: inline-block; min-width: 170px; }
          .token-value { color: #0078D7; font-weight: bold; }
          .token-status { font-size: 1.1em; }
          .delete-btn {
            background: #e53935;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 7px 18px;
            font-size: 1em;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.2s;
          }
          .delete-btn:hover { background: #b71c1c; }
          .token-row { margin-bottom: 7px; }
        </style>
      </head>
      <body>
        <h2>متابعة التوكنات (Token Tracker)</h2>
        <div class="tokens-container">
        ${Object.values(trackedTokens)
          .sort((a, b) => b.startTime - a.startTime) // الأحدث أولاً
          .map(t => {
            let percent = '';
            if (t.firstPrice && t.lastPrice) {
              const p = ((t.lastPrice - t.firstPrice) / t.firstPrice) * 100;
              percent = (p >= 0 ? '+' : '') + p.toFixed(2) + '%';
            } else {
              percent = '...';
            }
            // حساب مدة المراقبة hh:mm:ss
            let duration = '...';
            if (t.startTime) {
              const ms = Date.now() - t.startTime.getTime();
              const totalSeconds = Math.floor(ms / 1000);
              const hours = Math.floor(totalSeconds / 3600);
              const minutes = Math.floor((totalSeconds % 3600) / 60);
              const seconds = totalSeconds % 60;
              duration = `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
            }
            return `
              <div class="token-block">
                <div class="token-row"><span class="token-label">⏰ تاريخ ووقت بداية المراقبة:</span> <span>${t.startTime.toLocaleString('sv-SE').replace('T',' ')}</span></div>
                <div class="token-row"><span class="token-label">🔹 التوكن:</span> <span class="token-value">${t.token}</span></div>
                <div class="token-row"><span class="token-label">💵 أول سعر مراقب:</span> <span>${t.firstPrice ? t.firstPrice+'$' : 'جاري التحميل...'}</span></div>
                <div class="token-row"><span class="token-label">📈 أعلى سعر وصله:</span> <span style="color:green">${t.lastPrice ? t.lastPrice+'$' : 'جاري التحميل...'}</span></div>
                <div class="token-row"><span class="token-label">📊 نسبة الارتفاع من أول سعر:</span> <span>${percent}</span></div>
                <div class="token-row"><span class="token-label">🚀 هل ارتفع 50% أو أكثر:</span> <span class="token-status">${t.reached50 ? '✅️' : '❌️'}</span></div>
                <div class="token-row"><span class="token-label">⏳ مدة المراقبة:</span> <span>${duration}</span></div>
                <form method="POST" action="/delete_token" style="display:inline;">
                  <input type="hidden" name="token" value="${t.token}" />
                  <button type="submit" class="delete-btn">حذف من المراقبة</button>
                </form>
              </div>
            `;
          }).join('')}
        </div>
      </body>
      </html>
    `);
    return;
  }

  if (req.method === "POST" && req.url === "/delete_token") {
    let body = "";
    req.on("data", chunk => { body += chunk.toString(); });
    req.on("end", () => {
      const params = new URLSearchParams(body);
      const token = params.get("token");
      stopTrackingToken(token);
      res.writeHead(302, { Location: "/track_token" });
      res.end();
    });
    return;
  }
  // ...existing code...
}).listen(PORT, () => {
  console.log(`🌐 HTTP Server running on port ${PORT}`);
});

const KEEP_ALIVE_URL = "https://cdcd.onrender.com/";
setInterval(() => {
  https.get(KEEP_ALIVE_URL, (res) => {
    console.log(`🔄 Keep Alive Ping: ${KEEP_ALIVE_URL} - Status: ${res.statusCode}`);
  }).on("error", (e) => {
    console.error(`❌ Keep Alive Error: ${e.message}`);
  });
}, 10 * 60 * 1000); // كل 10 دقائق

// تسجيل الخروج عند إنهاء العملية
process.on('exit', () => {
  logLoginLogout('logout');
});
process.on('SIGINT', () => {
  logLoginLogout('logout');
  process.exit();
});

const sentTokensFile = 'sent_tokens.txt';
let sentTokens = new Set();
if (fs.existsSync(sentTokensFile)) {
  const tokens = fs.readFileSync(sentTokensFile, 'utf8').split('\n').filter(Boolean);
  sentTokens = new Set(tokens);
}

// تحسين الأداء عبر تقليل عمليات الإدخال/الإخراج (I/O) والكتابة المجمعة
const executionLogsBuffer = [];

// كتابة السجلات المجمعة إلى الملف بشكل دوري
setInterval(() => {
  if (executionLogsBuffer.length > 0) {
    fs.appendFileSync('execution_logs.txt', executionLogsBuffer.join(''), 'utf8');
    executionLogsBuffer.length = 0;
  }
}, 5000); // كل 5 ثوانٍ
